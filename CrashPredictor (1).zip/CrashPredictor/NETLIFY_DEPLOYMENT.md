# Netlify Deployment Guide

## Prerequisites
- Netlify account (https://app.netlify.com)
- Firebase project with credentials
- GitHub repository (recommended)

## Step 1: Prepare Firebase Credentials

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your project
3. Go to ⚙️ Settings → Service Accounts
4. Click "Generate New Private Key"
5. Save the entire JSON content

## Step 2: Set Up Environment Variables on Netlify

1. Go to your Netlify Site Settings
2. Navigate to "Build & Deploy" → "Environment"
3. Add these variables:

```
FIREBASE_SERVICE_ACCOUNT=<paste entire JSON from step 1>
FIREBASE_DATABASE_URL=https://your-project-id.firebaseio.com
NODE_ENV=production
```

## Step 3: Deploy to Netlify

### Option A: Via GitHub (Recommended)
1. Push your code to GitHub
2. Connect GitHub repo to Netlify
3. Netlify automatically detects `netlify.toml`
4. Deployment starts automatically

### Option B: Via CLI
```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

## Step 4: Configure Build Settings

- **Build command**: `npm run build`
- **Publish directory**: `dist/public`
- **Functions directory**: `netlify/functions`

## Important Notes

⚠️ **API Routes**: All `/api/*` routes are redirected to Netlify Functions
⚠️ **Firebase**: Ensure credentials are set in environment variables
⚠️ **Data Persistence**: Data stored in Firestore (automatically persisted)

## Troubleshooting

### API returns 404
- Check `netlify.toml` redirects
- Verify `netlify/functions/api.ts` exists

### Firebase connection fails
- Verify `FIREBASE_SERVICE_ACCOUNT` is valid JSON
- Check `FIREBASE_DATABASE_URL` format

### Build fails
- Run `npm install` locally
- Check Node.js version (v20+ recommended)
- Review build logs in Netlify dashboard

## Post-Deployment

1. Test API endpoints: `https://your-site.netlify.app/api/users/me/[userId]`
2. Verify notifications work
3. Check browser console for errors
4. Monitor Netlify function logs
