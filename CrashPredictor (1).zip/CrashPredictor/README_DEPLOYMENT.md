# 🚀 Crash Game Predictor - Deployment Guide

## Quick Start for Netlify

### 1. Firebase Setup (5 min)
```bash
# Get from Firebase Console:
# - Service Account JSON
# - Database URL
# Copy to safe location
```

### 2. Netlify Deploy (2 min)
```bash
# Option A: Via CLI
netlify login
netlify deploy --prod

# Option B: Via GitHub
# Push to GitHub → Connect to Netlify → Auto deploy
```

### 3. Set Environment Variables
In Netlify Site Settings → Build & Deploy → Environment:
```
FIREBASE_SERVICE_ACCOUNT=<your-json>
FIREBASE_DATABASE_URL=https://your-db.firebaseio.com
```

### 4. Test
```
https://your-site.netlify.app
```

## File Structure Ready for Deployment

```
project/
├── netlify.toml                    # Netlify configuration
├── netlify/functions/api.ts        # API serverless function
├── vite.config.production.ts       # Production build config
├── .env.example                    # Environment variables template
├── NETLIFY_DEPLOYMENT.md           # Detailed deployment guide
├── DEPLOYMENT_CHECKLIST.md         # Pre-flight checklist
├── client/src/                     # React frontend
├── server/                         # Express backend
└── shared/                         # Shared types & schemas
```

## Key Changes Made

1. ✅ `netlify.toml` - Netlify build configuration
2. ✅ `netlify/functions/api.ts` - Serverless API handler
3. ✅ `.env.example` - Environment variables template
4. ✅ Production build optimizations
5. ✅ Proper API redirects configured

## Important Notes

⚠️ **Firebase Credentials** - Store securely in Netlify Environment Variables
⚠️ **Build Command** - Must be: `npm run build`
⚠️ **Functions** - All `/api/*` routed to serverless functions
⚠️ **Data** - Persisted in Firebase Firestore (not lost on deploy)

## Next Steps

1. [ ] Get Firebase credentials from Firebase Console
2. [ ] Add credentials to Netlify environment
3. [ ] Test all features after deployment
4. [ ] Enable HTTPS (automatic with Netlify)
5. [ ] Configure custom domain (optional)

## Support

If deployment fails:
1. Check Netlify build logs
2. Verify Firebase credentials format
3. Review `NETLIFY_DEPLOYMENT.md`
4. Check console for errors

Good luck! 🚀
