import { z } from "zod";

// User Schema
export const userSchema = z.object({
  id: z.string(),
  deviceId: z.string(),
  isBanned: z.boolean().default(false),
  isPremium: z.boolean().default(false),
  joinedAt: z.number(),
  lastActive: z.number(),
});

export type User = z.infer<typeof userSchema>;

export const insertUserSchema = userSchema.omit({ joinedAt: true, lastActive: true });
export type InsertUser = z.infer<typeof insertUserSchema>;

// Chat Message Schema
export const chatMessageSchema = z.object({
  id: z.string(),
  userId: z.string(),
  sender: z.enum(["user", "admin"]),
  text: z.string().optional(),
  imageUrl: z.string().optional(),
  timestamp: z.number(),
  read: z.boolean().default(false),
});

export type ChatMessage = z.infer<typeof chatMessageSchema>;

export const insertChatMessageSchema = chatMessageSchema.omit({ id: true, timestamp: true });
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

// Notification Schema
export const notificationSchema = z.object({
  id: z.string(),
  title: z.string(),
  message: z.string(),
  timestamp: z.number(),
  target: z.string(), // 'all' or specific user ID
  read: z.boolean().default(false),
});

export type Notification = z.infer<typeof notificationSchema>;

export const insertNotificationSchema = notificationSchema.omit({ id: true, timestamp: true });
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

// Prediction History Schema
export const predictionSchema = z.object({
  id: z.string(),
  userId: z.string(),
  platform: z.enum(["1XBET", "LINEBET"]),
  prediction: z.string(),
  timestamp: z.number(),
});

export type Prediction = z.infer<typeof predictionSchema>;

export const insertPredictionSchema = predictionSchema.omit({ id: true, timestamp: true });
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;

// Admin Device Schema  
export const adminDeviceSchema = z.object({
  deviceId: z.string(),
  registeredAt: z.number(),
});

export type AdminDevice = z.infer<typeof adminDeviceSchema>;

// Login Schema
export const loginSchema = z.object({
  userId: z.string().regex(/^\d{8,12}$/, "ID must be 8-12 digits"),
  password: z.string(),
  deviceId: z.string(),
});

export type LoginRequest = z.infer<typeof loginSchema>;
