# Crash Game Predictor - Deployment Checklist

## Pre-Deployment

- [ ] All tests pass locally: `npm run check`
- [ ] Build succeeds: `npm run build`
- [ ] Firebase credentials are valid
- [ ] Database URL is correct
- [ ] All API endpoints tested in browser
- [ ] Notifications permission working
- [ ] Messages display correctly
- [ ] Admin panel fully functional
- [ ] No console errors
- [ ] No security issues (check secrets not committed)

## Firebase Setup

- [ ] Service account JSON prepared
- [ ] Firestore database created
- [ ] Database rules configured for security
- [ ] Backup enabled (optional)

## Netlify Configuration

- [ ] `netlify.toml` file created
- [ ] Build command configured: `npm run build`
- [ ] Functions directory set: `netlify/functions`
- [ ] Publish directory set: `dist/public`
- [ ] Node.js 20 selected
- [ ] All environment variables added:
  - [ ] FIREBASE_SERVICE_ACCOUNT
  - [ ] FIREBASE_DATABASE_URL
  - [ ] NODE_ENV=production

## Security

- [ ] No secrets committed to git
- [ ] Environment variables in .gitignore
- [ ] Firebase security rules reviewed
- [ ] Admin password changed from default
- [ ] Device ID banning functional
- [ ] No console.log with sensitive data

## Testing After Deploy

- [ ] Homepage loads
- [ ] Login works (both user and admin)
- [ ] Predictions generate correctly
- [ ] Messages send and receive
- [ ] Notifications display
- [ ] Ban system functional
- [ ] Premium toggle works
- [ ] Admin panel accessible
- [ ] Real-time updates work

## Performance

- [ ] Page loads under 3 seconds
- [ ] API responds under 500ms
- [ ] No console errors or warnings
- [ ] CSS/JS properly minified
- [ ] Images optimized

## Monitoring

- [ ] Enable Netlify analytics
- [ ] Monitor Firebase usage
- [ ] Set up error alerts
- [ ] Enable function logs
- [ ] Regular backup schedule

## Domain & SSL

- [ ] Custom domain configured (optional)
- [ ] SSL certificate active
- [ ] CORS configured properly
- [ ] Redirects working

## Documentation

- [ ] README updated with live link
- [ ] Deployment guide shared with team
- [ ] API endpoints documented
- [ ] Firebase credentials in secure location
