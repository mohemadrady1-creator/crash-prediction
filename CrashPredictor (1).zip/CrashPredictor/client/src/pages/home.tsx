import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MonitorPlay, Send, Activity, Zap, Youtube, LogOut, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { toast } from "sonner";
import bgImage from "@assets/generated_images/cyberpunk_security_background.png";
import { authAPI, predictionAPI, notificationAPI, type User } from "@/lib/api";
import { translations, Language } from "@/lib/translations";
import ChatWidget from "@/components/ChatWidget";

type Platform = "1XBET" | "LINEBET";

export default function Dashboard() {
  const [platform, setPlatform] = useState<Platform | null>(null);
  const [prediction, setPrediction] = useState<string | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [lang, setLang] = useState<Language>("en");
  const [_, setLocation] = useLocation();
  const [activeUsers, setActiveUsers] = useState(1240);

  useEffect(() => {
    const storedLang = localStorage.getItem("language") as Language;
    if (storedLang) setLang(storedLang);

    if (localStorage.getItem("isAuthenticated") !== "true") {
      setLocation("/");
      return;
    }

    const userId = localStorage.getItem("userId");
    if (!userId) return;

    // Request notification permission on mount
    const requestNotificationPermission = async () => {
      try {
        if ("Notification" in window) {
          if (Notification.permission === "granted") {
            console.log("✅ Notifications already enabled");
            return;
          }
          
          if (Notification.permission !== "denied") {
            const permission = await Notification.requestPermission();
            if (permission === "granted") {
              console.log("✅ Notification permission granted");
              toast.success("Notifications enabled");
            }
          }
        }
      } catch (error) {
        console.error("Failed to request notification permission:", error);
      }
    };

    requestNotificationPermission();

    const seenNotifications = new Set<string>();

    const checkStatus = async () => {
      try {
        const u = await authAPI.getMe(userId);
        setUser(u);
        
        if (u.isBanned) {
          localStorage.clear();
          toast.error("Access Denied - Device Banned");
          setLocation("/");
          return;
        }
        
        try {
          const notifs = await notificationAPI.getNotifications(userId);
          console.log("📬 All notifications:", notifs);
          const unread = notifs.filter(n => !seenNotifications.has(n.id));
          console.log("🔔 Unread notifications:", unread);
          
          unread.forEach(n => {
            seenNotifications.add(n.id);
            console.log("📢 Showing notification:", n.title);
            
            // Show toast notification
            toast(n.title, { 
              description: n.message,
              duration: 5000
            });
            
            // Show browser notification
            if ("Notification" in window && Notification.permission === "granted") {
              try {
                new Notification(n.title, {
                  body: n.message,
                  icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%23000'/><circle cx='50' cy='50' r='40' fill='%2300ff9d'/></svg>",
                  badge: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='50' fill='%2300ff9d'/></svg>",
                  tag: `notif-${n.id}`,
                  requireInteraction: false
                });
              } catch (err) {
                console.error("Failed to show notification:", err);
              }
            }
          });
        } catch (notifError) {
          console.error("Failed to load notifications:", notifError);
        }
      } catch (error) {
        console.error("Status check failed:", error);
      }
    };
    
    checkStatus();
    const interval = setInterval(checkStatus, 2000);
    return () => clearInterval(interval);
  }, [setLocation]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveUsers(prev => prev + Math.floor(Math.random() * 5) - 2);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const generatePrediction = async () => {
    if (!platform) return;
    setIsAnimating(true);
    setPrediction(null);

    setTimeout(async () => {
      const rand = Math.random();
      let integerPart;
      if (rand < 0.5) integerPart = 1;
      else if (rand < 0.8) integerPart = 2;
      else if (rand < 0.95) integerPart = 3;
      else integerPart = 4;

      const decimalPart = Math.floor(Math.random() * 99) + 1;
      const formattedDecimal = decimalPart < 10 ? `0${decimalPart}` : decimalPart;
      const predictionValue = `${integerPart}.${formattedDecimal}X`;

      setPrediction(predictionValue);
      setIsAnimating(false);

      if (user) {
        try {
          await predictionAPI.savePrediction(user.id, platform, predictionValue);
        } catch (error) {
          console.error("Failed to save prediction:", error);
        }
      }
    }, 1500);
  };

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated");
    setLocation("/");
  };

  const t = translations[lang];

  return (
    <div 
      className="min-h-screen bg-background text-foreground font-sans flex flex-col relative overflow-hidden"
      dir={lang === "ar" ? "rtl" : "ltr"}
    >
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none z-0"
        style={{ 
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <header className="relative z-10 border-b border-primary/20 bg-black/50 backdrop-blur-md p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Activity className="text-primary h-6 w-6 animate-pulse" />
          <span className="font-mono font-bold text-xl tracking-widest text-primary glitch-text" data-text="CRASH_PREDICTOR">
            CRASH_PREDICTOR
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-xs font-mono text-primary/70">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"/>
            {activeUsers} {t.users_online}
          </div>
          <Button variant="ghost" size="icon" onClick={handleLogout} className="text-primary hover:text-primary/80 hover:bg-primary/10">
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <main className="flex-1 relative z-10 p-4 flex flex-col items-center justify-center max-w-md mx-auto w-full gap-6">
        
        {user && (
          <div className="w-full flex justify-between items-center bg-black/40 p-2 rounded border border-white/10">
             <div className="flex items-center gap-2">
               <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center text-primary font-bold">
                 {user.id.substr(0,2)}
               </div>
               <div className="flex flex-col">
                 <span className="text-xs font-mono text-primary">{user.id}</span>
                 <span className="text-[10px] text-primary/50">{user.deviceId}</span>
               </div>
             </div>
             {user.isPremium ? (
               <div className="flex items-center gap-1 text-yellow-500 text-xs font-bold border border-yellow-500/30 px-2 py-1 rounded bg-yellow-500/10">
                 <Crown className="w-3 h-3" /> {t.premium_active}
               </div>
             ) : (
               <div className="text-xs text-primary/30 font-mono">{t.free_mode}</div>
             )}
          </div>
        )}

        <div className="grid grid-cols-2 gap-4 w-full">
          {["1XBET", "LINEBET"].map((p) => (
            <button
              key={p}
              onClick={() => setPlatform(p as Platform)}
              className={`
                relative group overflow-hidden p-4 rounded-lg border-2 transition-all duration-300
                ${platform === p 
                  ? "border-primary bg-primary/20 shadow-[0_0_20px_rgba(0,255,157,0.3)]" 
                  : "border-white/10 bg-black/40 hover:border-primary/50"
                }
              `}
            >
              <div className="font-mono font-bold text-lg text-center tracking-wider">
                {p}
              </div>
              {platform === p && (
                <div className="absolute inset-0 bg-primary/5 animate-pulse pointer-events-none" />
              )}
            </button>
          ))}
        </div>

        <Card className="w-full aspect-square bg-black/60 border-primary/30 backdrop-blur-xl relative overflow-hidden flex flex-col items-center justify-center shadow-[0_0_50px_rgba(0,255,157,0.05)]">
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%] pointer-events-none z-20" />
          
          <AnimatePresence mode="wait">
            {isAnimating ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center gap-4"
              >
                <div className="w-24 h-24 rounded-full border-4 border-primary/30 border-t-primary animate-spin" />
                <div className="font-mono text-primary/70 animate-pulse text-sm">{t.decrypting}</div>
              </motion.div>
            ) : prediction ? (
              <motion.div
                key="result"
                initial={{ scale: 0.5, opacity: 0, filter: "blur(10px)" }}
                animate={{ scale: 1, opacity: 1, filter: "blur(0px)" }}
                className="relative z-30"
              >
                <div className="font-mono text-7xl md:text-8xl font-black text-primary drop-shadow-[0_0_30px_rgba(0,255,157,0.8)] tracking-tighter glitch-text" data-text={prediction}>
                  {prediction}
                </div>
                <div className="text-center mt-2 font-mono text-xs text-primary/50 uppercase tracking-[0.2em]">
                  {t.probability}: 98.4%
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center space-y-2 opacity-50"
              >
                <MonitorPlay className="w-16 h-16 mx-auto mb-4 text-primary/50" />
                <div className="font-mono text-sm">{t.platform_select}</div>
              </motion.div>
            )}
          </AnimatePresence>
        </Card>

        <Button
          onClick={generatePrediction}
          disabled={!platform || isAnimating}
          className={`
            w-full h-16 text-xl font-bold font-mono tracking-widest border-2
            transition-all duration-300 relative overflow-hidden group
            ${!platform || isAnimating 
              ? "bg-secondary text-secondary-foreground/50 border-transparent cursor-not-allowed" 
              : "bg-primary text-black border-primary hover:shadow-[0_0_30px_rgba(0,255,157,0.6)]"
            }
          `}
        >
          <span className="relative z-10 flex items-center justify-center gap-3">
            <Zap className={`w-6 h-6 ${isAnimating ? "animate-bounce" : ""}`} />
            {isAnimating ? t.hacking : t.predict_btn}
          </span>
          {!isAnimating && platform && (
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          )}
        </Button>

        <div className="w-full text-[10px] text-primary/40 font-mono text-center border-t border-primary/10 pt-4">
           {t.instructions_step3} • {t.instructions_step5}
        </div>

      </main>

      <footer className="relative z-10 p-6 border-t border-primary/10 bg-black/80 backdrop-blur-lg mt-auto">
        <div className="flex justify-center items-center gap-8 mb-4">
          <a 
            href="https://t.me/xpolice_ban" 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-3 rounded-full bg-[#0088cc]/10 text-[#0088cc] border border-[#0088cc]/20 hover:bg-[#0088cc] hover:text-white transition-all duration-300 hover:scale-110"
          >
            <Send className="w-6 h-6" />
          </a>
          <a 
            href="https://youtube.com/@police_ban?si=JavekkPa8Thl0Awq" 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-3 rounded-full bg-[#ff0000]/10 text-[#ff0000] border border-[#ff0000]/20 hover:bg-[#ff0000] hover:text-white transition-all duration-300 hover:scale-110"
          >
            <Youtube className="w-6 h-6" />
          </a>
        </div>
      </footer>

      {user && <ChatWidget userId={user.id} language={lang} />}
    </div>
  );
}
