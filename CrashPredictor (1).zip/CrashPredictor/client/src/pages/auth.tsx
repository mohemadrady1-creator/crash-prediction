import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Shield, Lock, KeyRound, AlertCircle, Globe, HelpCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import bgImage from "@assets/generated_images/cyberpunk_security_background.png";
import LoadingScreen from "@/components/LoadingScreen";
import { getDeviceId, authAPI } from "@/lib/api";
import { translations, Language } from "@/lib/translations";
import { toast } from "sonner";

export default function AuthPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lang, setLang] = useState<Language>("en");
  const [_, setLocation] = useLocation();
  const t = translations[lang];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsSubmitting(true);

    try {
      const deviceId = getDeviceId();
      const response = await authAPI.login(id, password, deviceId);

      if (response.success) {
        localStorage.setItem("isAuthenticated", "true");
        localStorage.setItem("userId", id);
        localStorage.setItem("language", lang);
        
        if (response.isAdmin) {
          localStorage.setItem("isAdmin", "true");
          toast.success("Admin Access Granted");
          setLocation("/admin");
        } else {
          toast.success("Login Successful");
          setLocation("/dashboard");
        }
      }
    } catch (err: any) {
      const errorMsg = err.message || "Login failed";
      if (errorMsg.includes("UNAUTHORIZED_DEVICE")) {
        setError("UNAUTHORIZED DEVICE FOR ADMIN ACCESS");
      } else if (errorMsg.includes("INVALID_PASSWORD")) {
        setError(t.error_pass);
      } else if (errorMsg.includes("DEVICE_BANNED")) {
        setError(t.error_banned);
      } else if (errorMsg.includes("VALIDATION_ERROR")) {
        setError(t.error_id);
      } else {
        setError("Connection Error - Please try again");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return <LoadingScreen onComplete={() => setIsLoading(false)} />;
  }

  return (
    <div 
      className="min-h-screen w-full flex items-center justify-center p-4 bg-cover bg-center relative"
      style={{ backgroundImage: `url(${bgImage})` }}
      dir={lang === "ar" ? "rtl" : "ltr"}
    >
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      
      {/* Language Toggle */}
      <div className="absolute top-4 right-4 z-20">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setLang(l => l === "en" ? "ar" : "en")}
          className="bg-black/50 border-primary/50 text-primary"
        >
          <Globe className="w-4 h-4 mr-2" />
          {lang === "en" ? "العربية" : "ENGLISH"}
        </Button>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-md"
      >
        <Card className="border-primary/50 bg-black/80 shadow-[0_0_30px_rgba(0,255,157,0.1)] backdrop-blur-xl">
          <CardHeader className="text-center space-y-2">
            <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center border border-primary/50 mb-4">
              <Shield className="w-8 h-8 text-primary animate-pulse" />
            </div>
            <CardTitle className="text-3xl font-bold font-mono text-primary tracking-wider">
              {t.login_title}
            </CardTitle>
            <CardDescription className="text-primary/60 font-mono">
              {t.login_subtitle}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <div className="relative">
                  <KeyRound className={`absolute top-3 h-5 w-5 text-primary/50 ${lang === "ar" ? "right-3" : "left-3"}`} />
                  <Input
                    type="text"
                    placeholder={t.userid_placeholder}
                    className={`${lang === "ar" ? "pr-10" : "pl-10"} bg-secondary/50 border-primary/30 text-primary placeholder:text-primary/30 font-mono tracking-widest focus-visible:ring-primary`}
                    value={id}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '');
                      if (val.length <= 12) setId(val);
                    }}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="relative">
                  <Lock className={`absolute top-3 h-5 w-5 text-primary/50 ${lang === "ar" ? "right-3" : "left-3"}`} />
                  <Input
                    type="password"
                    placeholder={t.password_placeholder}
                    className={`${lang === "ar" ? "pr-10" : "pl-10"} bg-secondary/50 border-primary/30 text-primary placeholder:text-primary/30 font-mono tracking-widest focus-visible:ring-primary`}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>

              {error && (
                <Alert variant="destructive" className="bg-destructive/10 border-destructive/50 text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="font-mono uppercase text-xs font-bold">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              <Button 
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-primary hover:bg-primary/90 text-background font-bold font-mono tracking-wider h-12 border-b-4 border-primary/50 hover:border-primary active:border-b-0 active:translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? "CONNECTING..." : t.login_btn}
              </Button>

              {/* Instructions Modal Trigger */}
              <div className="text-center">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="link" className="text-primary/50 text-xs hover:text-primary">
                      <HelpCircle className="w-3 h-3 mr-1" /> {t.instructions_title}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black border-primary/50 text-primary font-mono">
                    <DialogHeader>
                      <DialogTitle>{t.instructions_title}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 mt-4 text-sm">
                      <p>1. {t.instructions_step1}</p>
                      <p>2. {t.instructions_step2}</p>
                      <p>3. {t.instructions_step3}</p>
                      <p>4. {t.instructions_step4}</p>
                      <p>5. {t.instructions_step5}</p>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Social Links */}
              <div className="flex justify-center gap-4 pt-4 border-t border-white/10">
                <a 
                  href="https://t.me/xpolice_ban" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="opacity-50 hover:opacity-100 transition-opacity"
                >
                  <img src="https://upload.wikimedia.org/wikipedia/commons/8/82/Telegram_logo.svg" className="w-6 h-6" alt="Telegram" />
                </a>
                <a 
                  href="https://youtube.com/@police_ban?si=JavekkPa8Thl0Awq" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="opacity-50 hover:opacity-100 transition-opacity"
                >
                  <img src="https://upload.wikimedia.org/wikipedia/commons/0/09/YouTube_full-color_icon_%282017%29.svg" className="w-6 h-6" alt="YouTube" />
                </a>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
