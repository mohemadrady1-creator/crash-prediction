import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { adminAPI, notificationAPI, chatAPI, getDeviceId, type User, type ChatMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Ban, CheckCircle, AlertTriangle, Send, Search, LogOut, User as UserIcon } from "lucide-react";
import { toast } from "sonner";

export default function AdminPanel() {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [search, setSearch] = useState("");
  const [notifTitle, setNotifTitle] = useState("");
  const [notifMsg, setNotifMsg] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [_, setLocation] = useLocation();

  useEffect(() => {
    const deviceId = getDeviceId();
    const isAdmin = localStorage.getItem("isAdmin") === "true";

    if (!isAdmin) {
      toast.error("UNAUTHORIZED ACCESS ATTEMPT LOGGED");
      setLocation("/");
      return;
    }

    const refreshUsers = async () => {
      try {
        const allUsers = await adminAPI.getAllUsers();
        setUsers(allUsers);
      } catch (error) {
        console.error("Failed to fetch users:", error);
      }
    };
    
    refreshUsers();
    const interval = setInterval(refreshUsers, 3000);
    return () => clearInterval(interval);
  }, [setLocation]);

  useEffect(() => {
    if (!selectedUser) return;
    
    const loadMessages = async () => {
      try {
        const msgs = await chatAPI.getMessages(selectedUser.id);
        setChatMessages(msgs.sort((a, b) => a.timestamp - b.timestamp));
      } catch (error) {
        console.error("Failed to load messages:", error);
      }
    };

    loadMessages();
    const interval = setInterval(loadMessages, 1500);
    return () => clearInterval(interval);
  }, [selectedUser?.id]);

  const handleBan = async (userId: string, status: boolean) => {
    try {
      await adminAPI.banUser(userId, status);
      const allUsers = await adminAPI.getAllUsers();
      setUsers(allUsers);
      toast.success(`User ${status ? "BANNED" : "UNBANNED"}`);
    } catch (error) {
      toast.error("Action failed");
    }
  };

  const handlePremium = async (userId: string, status: boolean) => {
    try {
      await adminAPI.setPremium(userId, status);
      const allUsers = await adminAPI.getAllUsers();
      setUsers(allUsers);
      toast.success(`User Premium ${status ? "ACTIVATED" : "DEACTIVATED"}`);
    } catch (error) {
      toast.error("Action failed");
    }
  };

  const sendNotification = async (target: "all" | string) => {
    if (!notifTitle || !notifMsg) return;
    try {
      await notificationAPI.sendNotification(notifTitle, notifMsg, target);
      toast.success("Notification Sent");
      setNotifTitle("");
      setNotifMsg("");
    } catch (error) {
      toast.error("Failed to send notification");
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;
    
    const input = document.getElementById("admin-chat-input") as HTMLInputElement;
    if (!input?.value.trim()) return;

    try {
      await chatAPI.sendMessage(selectedUser.id, "admin", input.value);
      input.value = "";
      setTimeout(() => {
        const loadMessages = async () => {
          const msgs = await chatAPI.getMessages(selectedUser.id);
          setChatMessages(msgs.sort((a, b) => a.timestamp - b.timestamp));
        };
        loadMessages();
      }, 300);
    } catch (error) {
      toast.error("Failed to send message");
    }
  };

  const filteredUsers = users.filter(u => 
    u.id.includes(search) || u.deviceId.includes(search)
  );

  return (
    <div className="min-h-screen bg-black text-green-500 font-mono p-6">
      <header className="flex justify-between items-center mb-8 border-b border-green-900 pb-4">
        <div>
          <h1 className="text-3xl font-bold tracking-widest">ADMIN_CONSOLE</h1>
          <p className="text-xs text-green-700 mt-1">SECURE CONNECTION :: DEVICE VERIFIED</p>
        </div>
        <Button variant="destructive" onClick={() => setLocation("/")}>
          <LogOut className="mr-2 h-4 w-4" /> EXIT
        </Button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Stats */}
        <Card className="bg-green-950/10 border-green-900 lg:col-span-3">
          <CardContent className="p-6 flex justify-around text-center">
            <div>
              <div className="text-2xl font-bold text-green-400">{users.length}</div>
              <div className="text-xs text-green-700">TOTAL USERS</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-400">
                {users.filter(u => !u.isBanned).length}
              </div>
              <div className="text-xs text-green-700">ACTIVE</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-400">
                {users.filter(u => u.isPremium).length}
              </div>
              <div className="text-xs text-green-700">PREMIUM</div>
            </div>
          </CardContent>
        </Card>

        {/* Users List */}
        <Card className="bg-green-950/10 border-green-900 lg:col-span-1 h-[600px] flex flex-col">
          <CardHeader>
            <CardTitle className="text-green-500 flex items-center gap-2">
              <UserIcon className="w-5 h-5" /> USERS
            </CardTitle>
            <Input 
              placeholder="Search ID/Device..." 
              className="bg-black border-green-900 text-green-500"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              data-testid="search-users"
            />
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto space-y-2 scrollbar-thin scrollbar-thumb-green-900">
            {filteredUsers.map(user => (
              <div 
                key={user.id}
                onClick={() => setSelectedUser(user)}
                className={`
                  p-3 rounded border cursor-pointer transition-colors
                  ${selectedUser?.id === user.id ? "bg-green-900/30 border-green-500" : "bg-black border-green-900 hover:border-green-700"}
                `}
                data-testid={`user-item-${user.id}`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold">{user.id}</span>
                  <Badge variant={user.isBanned ? "destructive" : "outline"} className="text-[10px]">
                    {user.isBanned ? "BANNED" : "ACTIVE"}
                  </Badge>
                </div>
                <div className="text-[10px] text-green-700 mt-1 truncate">{user.deviceId}</div>
                {user.isPremium && <div className="text-[10px] text-yellow-500 mt-1">★ PREMIUM</div>}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* User Details & Actions */}
        <Card className="bg-green-950/10 border-green-900 lg:col-span-2 h-[600px] flex flex-col">
          {selectedUser && (
            <>
              <CardHeader className="border-b border-green-900">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-xl">USER: {selectedUser.id}</CardTitle>
                    <div className="text-xs text-green-700 font-mono">{selectedUser.deviceId}</div>
                  </div>
                </div>
              </CardHeader>

              <Tabs defaultValue="info" className="flex-1 flex flex-col">
                <TabsList className="bg-black border-b border-green-900 rounded-none">
                  <TabsTrigger value="info" data-testid="tab-info">INFO</TabsTrigger>
                  <TabsTrigger value="chat" data-testid="tab-chat">CHAT</TabsTrigger>
                  <TabsTrigger value="notify" data-testid="tab-notify">NOTIFY</TabsTrigger>
                </TabsList>

                <div className="flex-1 overflow-y-auto p-4">
                  <TabsContent value="info" className="space-y-6 mt-0">
                    <div className="grid grid-cols-2 gap-4">
                      <Button 
                        variant={selectedUser.isBanned ? "default" : "destructive"}
                        onClick={() => handleBan(selectedUser.id, !selectedUser.isBanned)}
                        className="w-full"
                        data-testid={`ban-user-${selectedUser.id}`}
                      >
                        {selectedUser.isBanned ? <CheckCircle className="mr-2" /> : <Ban className="mr-2" />}
                        {selectedUser.isBanned ? "UNBAN DEVICE" : "BAN DEVICE"}
                      </Button>
                      
                      <Button 
                        className={`w-full ${selectedUser.isPremium ? "bg-yellow-600 hover:bg-yellow-700" : "bg-green-600 hover:bg-green-700"}`}
                        onClick={() => handlePremium(selectedUser.id, !selectedUser.isPremium)}
                        data-testid={`premium-user-${selectedUser.id}`}
                      >
                        {selectedUser.isPremium ? "REVOKE PREMIUM" : "GRANT PREMIUM"}
                      </Button>
                    </div>

                    <div className="bg-black p-4 rounded border border-green-900">
                      <h3 className="font-bold mb-2 border-b border-green-900 pb-1">DEVICE FINGERPRINT</h3>
                      <pre className="text-xs overflow-x-auto text-green-700 max-h-64">
                        {JSON.stringify(selectedUser, null, 2)}
                      </pre>
                    </div>
                  </TabsContent>

                  <TabsContent value="chat" className="mt-0 h-full">
                    <div className="h-full flex flex-col gap-2">
                      <div className="flex-1 bg-black/50 p-4 rounded overflow-y-auto text-sm space-y-2 border border-green-900/20" data-testid="messages-container">
                        {chatMessages.length === 0 ? (
                          <div className="text-center text-green-700/50">No messages yet</div>
                        ) : (
                          chatMessages.map(msg => (
                            <div key={msg.id} className={`flex ${msg.sender === "admin" ? "justify-end" : "justify-start"}`} data-testid={`message-${msg.id}`}>
                              <div className={`max-w-xs p-2 rounded ${msg.sender === "admin" ? "bg-green-900/40 border border-green-700" : "bg-gray-900 border border-gray-700"}`}>
                                <p className="text-xs text-gray-300">{msg.text}</p>
                                <span className="text-[10px] opacity-50 block mt-1">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                      <form onSubmit={sendMessage} className="flex gap-2">
                        <Input 
                          id="admin-chat-input" 
                          placeholder="Reply..." 
                          className="bg-black border-green-900 flex-1"
                          data-testid="chat-input"
                        />
                        <Button type="submit" className="bg-green-600 hover:bg-green-700" data-testid="send-message-btn">
                          <Send className="w-4 h-4" />
                        </Button>
                      </form>
                    </div>
                  </TabsContent>

                  <TabsContent value="notify" className="space-y-4 mt-0">
                    <Input 
                      placeholder="Notification Title" 
                      value={notifTitle}
                      onChange={e => setNotifTitle(e.target.value)}
                      className="bg-black border-green-900"
                      data-testid="notif-title"
                    />
                    <Input 
                      placeholder="Message Body" 
                      value={notifMsg}
                      onChange={e => setNotifMsg(e.target.value)}
                      className="bg-black border-green-900"
                      data-testid="notif-message"
                    />
                    <div className="flex gap-2 pt-4">
                      <Button onClick={() => sendNotification(selectedUser.id)} className="flex-1 bg-green-600 hover:bg-green-700" data-testid="send-to-user">
                        SEND TO THIS USER
                      </Button>
                      <Button variant="outline" onClick={() => sendNotification("all")} className="flex-1 border-green-900 text-green-500" data-testid="send-to-all">
                        SEND TO EVERYONE
                      </Button>
                    </div>
                  </TabsContent>
                </div>
              </Tabs>
            </>
          )}
          {!selectedUser && (
            <div className="flex items-center justify-center h-full text-green-900">
              SELECT A USER TO INSPECT
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
