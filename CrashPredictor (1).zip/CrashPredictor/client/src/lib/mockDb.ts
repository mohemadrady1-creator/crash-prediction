// Simulated Database and Firebase-like services using LocalStorage
// This allows the mockup to feel "real" and persistent without a backend

export type User = {
  id: string;
  deviceId: string;
  isBanned: boolean;
  isPremium: boolean;
  joinedAt: number;
  lastActive: number;
  messages: ChatMessage[];
};

export type ChatMessage = {
  id: string;
  sender: "user" | "admin";
  text?: string;
  image?: string;
  timestamp: number;
  read: boolean;
};

export type Notification = {
  id: string;
  title: string;
  message: string;
  timestamp: number;
  target: "all" | string; // 'all' or specific user ID
  read: boolean;
};

const DB_KEY = "crash_predictor_db_v1";
const DEVICE_ID_KEY = "crash_predictor_device_id";

// Helper to get unique device ID
export const getDeviceId = () => {
  let did = localStorage.getItem(DEVICE_ID_KEY);
  if (!did) {
    did = "DEV-" + Math.random().toString(36).substr(2, 9).toUpperCase();
    localStorage.setItem(DEVICE_ID_KEY, did);
  }
  return did;
};

// Initialize DB if empty
const initDb = () => {
  const db = localStorage.getItem(DB_KEY);
  if (!db) {
    const initialData = {
      users: {},
      adminDeviceId: null, // Will be set by first admin login
      notifications: [],
      globalSettings: {
        maintenanceMode: false,
      }
    };
    localStorage.setItem(DB_KEY, JSON.stringify(initialData));
    return initialData;
  }
  return JSON.parse(db);
};

// MOCK API
export const db = {
  get: () => initDb(),
  save: (data: any) => localStorage.setItem(DB_KEY, JSON.stringify(data)),
  
  // User Actions
  registerUser: (userId: string) => {
    const data = db.get();
    const deviceId = getDeviceId();
    
    if (!data.users[userId]) {
      data.users[userId] = {
        id: userId,
        deviceId,
        isBanned: false,
        isPremium: false,
        joinedAt: Date.now(),
        lastActive: Date.now(),
        messages: []
      };
    } else {
      // Update last active
      data.users[userId].lastActive = Date.now();
      // Check if device matches (simple security check simulation)
      // In real app, we'd handle multiple devices, but here we stick to the requested "Device ID" logic
    }
    db.save(data);
    return data.users[userId];
  },

  getUser: (userId: string) => {
    const data = db.get();
    return data.users[userId];
  },

  // Admin Actions
  setAdminDevice: () => {
    const data = db.get();
    const currentDevice = getDeviceId();
    if (!data.adminDeviceId) {
      data.adminDeviceId = currentDevice;
      db.save(data);
      return true;
    }
    return data.adminDeviceId === currentDevice;
  },

  isAdminDevice: () => {
    const data = db.get();
    return data.adminDeviceId === getDeviceId();
  },

  getAllUsers: () => {
    const data = db.get();
    // Generate some fake users to make the admin panel look busy
    const fakeUsers = Array.from({ length: 5 }).map((_, i) => ({
      id: `89233${i}12`,
      deviceId: `DEV-FAKE-${i}`,
      isBanned: Math.random() > 0.9,
      isPremium: Math.random() > 0.7,
      joinedAt: Date.now() - 1000000 * i,
      lastActive: Date.now() - Math.random() * 100000,
      messages: []
    }));
    return [...Object.values(data.users), ...fakeUsers];
  },

  banUser: (userId: string, status: boolean) => {
    const data = db.get();
    if (data.users[userId]) {
      data.users[userId].isBanned = status;
      db.save(data);
    }
  },

  setPremium: (userId: string, status: boolean) => {
    const data = db.get();
    if (data.users[userId]) {
      data.users[userId].isPremium = status;
      db.save(data);
    }
  },

  // Chat
  sendMessage: (userId: string, text: string, image?: string, sender: "user" | "admin" = "user") => {
    const data = db.get();
    if (data.users[userId]) {
      const msg: ChatMessage = {
        id: Math.random().toString(36).substr(2, 9),
        sender,
        text,
        image,
        timestamp: Date.now(),
        read: false
      };
      data.users[userId].messages.push(msg);
      db.save(data);
    }
  },

  deleteMessage: (userId: string, msgId: string) => {
    const data = db.get();
    if (data.users[userId]) {
      data.users[userId].messages = data.users[userId].messages.filter((m: ChatMessage) => m.id !== msgId);
      db.save(data);
    }
  },

  // Notifications
  sendNotification: (title: string, message: string, target: "all" | string) => {
    const data = db.get();
    const notif: Notification = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      message,
      timestamp: Date.now(),
      target,
      read: false
    };
    data.notifications.push(notif);
    db.save(data);
  },

  getNotifications: (userId: string) => {
    const data = db.get();
    return data.notifications.filter((n: Notification) => n.target === "all" || n.target === userId);
  }
};
