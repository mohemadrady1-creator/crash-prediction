// API Client for backend communication

export type User = {
  id: string;
  deviceId: string;
  isBanned: boolean;
  isPremium: boolean;
  joinedAt: number;
  lastActive: number;
};

export type ChatMessage = {
  id: string;
  userId: string;
  sender: "user" | "admin";
  text?: string;
  imageUrl?: string;
  timestamp: number;
  read: boolean;
};

export type Notification = {
  id: string;
  title: string;
  message: string;
  timestamp: number;
  target: string;
  read: boolean;
};

export type Prediction = {
  id: string;
  userId: string;
  platform: "1XBET" | "LINEBET";
  prediction: string;
  timestamp: number;
};

const API_BASE = "/api";

// Helper function
async function fetchAPI<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: "Unknown error" }));
    throw new Error(error.error || "Request failed");
  }

  return response.json();
}

// Auth API
export const authAPI = {
  login: (userId: string, password: string, deviceId: string) =>
    fetchAPI<{ success: boolean; isAdmin: boolean; user: User }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ userId, password, deviceId }),
    }),

  getMe: (userId: string) =>
    fetchAPI<User>(`/users/me/${userId}`),
};

// Admin API
export const adminAPI = {
  getAllUsers: () =>
    fetchAPI<User[]>("/admin/users"),

  banUser: (userId: string, isBanned: boolean) =>
    fetchAPI<{ success: boolean }>(`/admin/users/${userId}/ban`, {
      method: "POST",
      body: JSON.stringify({ isBanned }),
    }),

  setPremium: (userId: string, isPremium: boolean) =>
    fetchAPI<{ success: boolean }>(`/admin/users/${userId}/premium`, {
      method: "POST",
      body: JSON.stringify({ isPremium }),
    }),
};

// Chat API
export const chatAPI = {
  getMessages: (userId: string) =>
    fetchAPI<ChatMessage[]>(`/chat/${userId}`),

  sendMessage: (userId: string, sender: "user" | "admin", text?: string, imageUrl?: string) =>
    fetchAPI<ChatMessage>("/chat", {
      method: "POST",
      body: JSON.stringify({ userId, sender, text, imageUrl }),
    }),

  deleteMessage: (userId: string, messageId: string) =>
    fetchAPI<{ success: boolean }>(`/chat/${userId}/${messageId}`, {
      method: "DELETE",
    }),
};

// Notifications API
export const notificationAPI = {
  getNotifications: (userId: string) =>
    fetchAPI<Notification[]>(`/notifications/${userId}`),

  sendNotification: (title: string, message: string, target: string) =>
    fetchAPI<Notification>("/notifications", {
      method: "POST",
      body: JSON.stringify({ title, message, target }),
    }),
};

// Predictions API
export const predictionAPI = {
  getPredictions: (userId: string) =>
    fetchAPI<Prediction[]>(`/predictions/${userId}`),

  savePrediction: (userId: string, platform: "1XBET" | "LINEBET", prediction: string) =>
    fetchAPI<Prediction>("/predictions", {
      method: "POST",
      body: JSON.stringify({ userId, platform, prediction }),
    }),
};

// Device ID Management
const DEVICE_ID_KEY = "crash_predictor_device_id";

export const getDeviceId = () => {
  let did = localStorage.getItem(DEVICE_ID_KEY);
  if (!did) {
    did = "DEV-" + Math.random().toString(36).substr(2, 9).toUpperCase();
    localStorage.setItem(DEVICE_ID_KEY, did);
  }
  return did;
};
