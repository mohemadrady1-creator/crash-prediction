import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Terminal, Lock, Wifi, ShieldCheck } from "lucide-react";

export default function LoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const steps = [
    { text: "INITIALIZING BOOT SEQUENCE...", icon: Terminal },
    { text: "ESTABLISHING SECURE HANDSHAKE...", icon: Lock },
    { text: "CONNECTING TO GLOBAL NETWORK...", icon: Wifi },
    { text: "VERIFYING SECURITY PROTOCOLS...", icon: ShieldCheck },
    { text: "ACCESS GRANTED", icon: ShieldCheck }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setStep(s => {
        if (s >= steps.length - 1) {
          clearInterval(timer);
          setTimeout(onComplete, 1000);
          return s;
        }
        return s + 1;
      });
    }, 800);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-center text-primary font-mono p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="h-2 w-full bg-secondary/30 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-primary"
            initial={{ width: "0%" }}
            animate={{ width: `${((step + 1) / steps.length) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        
        <div className="space-y-2">
          {steps.map((s, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ 
                opacity: i <= step ? (i === step ? 1 : 0.5) : 0,
                x: i <= step ? 0 : -20
              }}
              className="flex items-center gap-3 text-sm md:text-base"
            >
              <s.icon className={`w-4 h-4 ${i === step ? "animate-pulse" : ""}`} />
              <span>{s.text}</span>
              {i === step && <span className="animate-pulse">_</span>}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
