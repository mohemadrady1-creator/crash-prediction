import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, X, Send, Image as ImageIcon, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { chatAPI, type ChatMessage } from "@/lib/api";
import { toast } from "sonner";

type ChatWidgetProps = {
  userId: string;
  isAdmin?: boolean;
  language?: "en" | "ar";
};

export default function ChatWidget({ userId, isAdmin = false, language = "en" }: ChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const loadMessages = async () => {
    try {
      const msgs = await chatAPI.getMessages(userId);
      setMessages(msgs.sort((a, b) => a.timestamp - b.timestamp));
    } catch (error) {
      console.error("Failed to load messages:", error);
    }
  };

  useEffect(() => {
    loadMessages();
    const interval = setInterval(loadMessages, 1500);
    return () => clearInterval(interval);
  }, [userId, isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    try {
      await chatAPI.sendMessage(userId, isAdmin ? "admin" : "user", input);
      setInput("");
      setTimeout(() => loadMessages(), 300);
    } catch (error) {
      toast.error("Failed to send message");
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          await chatAPI.sendMessage(userId, isAdmin ? "admin" : "user", "Sent an image", reader.result as string);
        } catch (error) {
          toast.error("Failed to send image");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDelete = async (msgId: string) => {
    if (isAdmin) {
      try {
        await chatAPI.deleteMessage(userId, msgId);
        toast.success("Message deleted");
      } catch (error) {
        toast.error("Failed to delete message");
      }
    }
  };

  return (
    <>
      {!isOpen && !isAdmin && (
        <motion.button
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          onClick={() => setIsOpen(true)}
          className="fixed bottom-20 right-4 z-50 p-4 bg-primary rounded-full shadow-[0_0_20px_rgba(0,255,157,0.4)] hover:scale-110 transition-transform"
          data-testid="chat-widget-button"
        >
          <MessageSquare className="w-6 h-6 text-black" />
        </motion.button>
      )}

      <AnimatePresence>
        {(isOpen || isAdmin) && (
          <motion.div
            initial={!isAdmin ? { opacity: 0, y: 100, scale: 0.9 } : { opacity: 1, y: 0, scale: 1 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className={`${
              isAdmin ? "h-full w-full border-none" : "fixed bottom-24 right-4 w-[350px] h-[500px] rounded-2xl border border-primary/30"
            } bg-black/90 backdrop-blur-xl shadow-2xl flex flex-col overflow-hidden z-50`}
            data-testid="chat-widget"
          >
            {!isAdmin && (
              <div className="p-4 border-b border-primary/20 flex justify-between items-center bg-primary/5">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="font-mono font-bold text-primary">SUPPORT_ONLINE</span>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-8 w-8 text-primary/50 hover:text-primary" data-testid="close-chat">
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-primary/20">
              {messages.length === 0 && (
                <div className="text-center text-primary/30 font-mono text-sm mt-10">
                  START_ENCRYPTED_CHAT...
                </div>
              )}
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === (isAdmin ? "admin" : "user") ? "justify-end" : "justify-start"}`}
                  data-testid={`message-${msg.id}`}
                >
                  <div
                    className={`
                      max-w-[80%] p-3 rounded-lg relative group
                      ${msg.sender === "admin" 
                        ? "bg-primary/20 border border-primary/30 text-primary-foreground" 
                        : "bg-secondary border border-white/10 text-foreground"
                      }
                    `}
                  >
                    {msg.imageUrl ? (
                      <img src={msg.imageUrl} alt="attachment" className="rounded-md max-w-full" />
                    ) : (
                      <p className="text-sm font-mono">{msg.text}</p>
                    )}
                    <div className="text-[10px] opacity-50 mt-1 text-right">
                      {new Date(msg.timestamp).toLocaleTimeString()}
                    </div>

                    {isAdmin && (
                       <button 
                         onClick={() => handleDelete(msg.id)}
                         className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                         data-testid={`delete-message-${msg.id}`}
                       >
                         <Trash2 className="w-3 h-3" />
                       </button>
                    )}
                  </div>
                </div>
              ))}
              <div ref={scrollRef} />
            </div>

            <div className="p-4 border-t border-primary/20 bg-black/40 flex gap-2">
              <label className="cursor-pointer p-2 hover:bg-primary/10 rounded-md transition-colors">
                <ImageIcon className="w-5 h-5 text-primary/50" />
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} data-testid="upload-image" />
              </label>
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder={language === "ar" ? "اكتب رسالة..." : "Type message..."}
                className="bg-transparent border-primary/20 text-primary font-mono text-sm"
                data-testid="chat-input"
              />
              <Button onClick={handleSend} size="icon" className="bg-primary text-black hover:bg-primary/80" data-testid="send-message">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
