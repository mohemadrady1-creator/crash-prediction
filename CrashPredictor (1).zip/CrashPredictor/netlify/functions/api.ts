import { Handler } from "@netlify/functions";
import express from "express";
import { registerRoutes } from "../../server/routes";
import { createServer } from "http";

// Create Express app
const app = express();
const httpServer = createServer(app);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Initialize routes
let routesInitialized = false;
const initializeRoutes = async () => {
  if (!routesInitialized) {
    await registerRoutes(httpServer, app);
    routesInitialized = true;
  }
};

// Netlify Function Handler
export const handler: Handler = async (event, context) => {
  // Initialize routes on first call
  await initializeRoutes();

  // Convert Netlify event to Express-compatible request/response
  return new Promise((resolve, reject) => {
    const req = {
      method: event.httpMethod,
      url: event.path + (event.queryStringParameters ? `?${new URLSearchParams(event.queryStringParameters).toString()}` : ""),
      headers: event.headers,
      body: event.body ? JSON.parse(event.body) : {},
    } as any;

    const res = {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: "",
    } as any;

    // Create mock Express request/response
    const mockReq = {
      method: event.httpMethod,
      path: event.path,
      query: event.queryStringParameters || {},
      params: {},
      headers: event.headers,
      body: event.body ? JSON.parse(event.body) : {},
      on: () => {},
    } as any;

    const mockRes = {
      statusCode: 200,
      json: (data: any) => {
        resolve({
          statusCode: mockRes.statusCode,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
      },
      status: (code: number) => {
        mockRes.statusCode = code;
        return mockRes;
      },
      send: (data: any) => {
        resolve({
          statusCode: mockRes.statusCode,
          body: typeof data === "string" ? data : JSON.stringify(data),
        });
      },
    } as any;

    // Route the request through Express
    app(mockReq, mockRes);
  });
};
