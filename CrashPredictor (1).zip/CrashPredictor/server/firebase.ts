import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
import { getMessaging } from 'firebase-admin/messaging';

let firebaseApp: admin.app.App | null = null;
let isInitialized = false;

export function initializeFirebase() {
  if (firebaseApp) {
    return firebaseApp;
  }

  const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT;
  
  if (!serviceAccount) {
    console.warn('⚠️  Firebase not configured - FIREBASE_SERVICE_ACCOUNT missing');
    isInitialized = false;
    return null;
  }

  try {
    // Parse the service account JSON
    let credentials;
    try {
      credentials = JSON.parse(serviceAccount);
    } catch (parseError) {
      console.error('❌ Failed to parse FIREBASE_SERVICE_ACCOUNT - ensure it contains valid JSON');
      console.error('Hint: Paste the entire content of your Firebase service account JSON file');
      isInitialized = false;
      return null;
    }
    
    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert(credentials),
      databaseURL: process.env.FIREBASE_DATABASE_URL
    });

    console.log('✅ Firebase initialized successfully');
    isInitialized = true;
    return firebaseApp;
  } catch (error) {
    console.error('❌ Failed to initialize Firebase:', error);
    isInitialized = false;
    return null;
  }
}

export function isFirebaseInitialized(): boolean {
  return isInitialized;
}

export function getFirestoreDb() {
  const app = initializeFirebase();
  if (!app) {
    throw new Error('Firebase not initialized - check your FIREBASE_SERVICE_ACCOUNT secret');
  }
  return getFirestore(app);
}

export function getFirebaseMessaging() {
  const app = initializeFirebase();
  if (!app) {
    throw new Error('Firebase not initialized');
  }
  return getMessaging(app);
}

export { admin };
