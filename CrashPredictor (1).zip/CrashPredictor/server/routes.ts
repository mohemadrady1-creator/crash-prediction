import type { Express } from "express";
import { createServer, type Server } from "http";
import { getStorage } from "./storage";
import { 
  loginSchema, 
  insertChatMessageSchema, 
  insertNotificationSchema,
  insertPredictionSchema 
} from "@shared/schema";
import { initializeFirebase } from "./firebase";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Firebase FIRST before using storage
  initializeFirebase();
  
  // Now get the storage instance which will use Firebase if available
  const storage = getStorage();

  // Authentication & User Management
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { userId, password, deviceId } = loginSchema.parse(req.body);

      // Check Admin Login
      if (userId === "803331313" && password === "HIX99V") {
        const adminDevice = await storage.getAdminDevice();
        
        if (!adminDevice) {
          await storage.setAdminDevice(deviceId);
          let user = await storage.getUser(userId);
          if (!user) {
            user = await storage.createUser({ id: userId, deviceId, isBanned: false, isPremium: true });
          }
          return res.json({ success: true, isAdmin: true, user });
        }
        
        if (adminDevice.deviceId === deviceId) {
          let user = await storage.getUser(userId);
          if (!user) {
            user = await storage.createUser({ id: userId, deviceId, isBanned: false, isPremium: true });
          }
          return res.json({ success: true, isAdmin: true, user });
        }
        
        return res.status(403).json({ error: "UNAUTHORIZED_DEVICE" });
      }

      // Regular User Login
      if (password !== "HIX99") {
        return res.status(401).json({ error: "INVALID_PASSWORD" });
      }

      let user = await storage.getUser(userId);
      
      if (user && user.isBanned) {
        return res.status(403).json({ error: "DEVICE_BANNED" });
      }

      if (!user) {
        user = await storage.createUser({ id: userId, deviceId, isBanned: false, isPremium: false });
      } else {
        await storage.updateUser(userId, { lastActive: Date.now() });
      }

      res.json({ success: true, isAdmin: false, user });
    } catch (error) {
      res.status(400).json({ error: "VALIDATION_ERROR" });
    }
  });

  app.get("/api/users/me/:userId", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ error: "USER_NOT_FOUND" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  // Admin Routes
  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  app.post("/api/admin/users/:userId/ban", async (req, res) => {
    try {
      const { isBanned } = req.body;
      await storage.updateUser(req.params.userId, { isBanned });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  app.post("/api/admin/users/:userId/premium", async (req, res) => {
    try {
      const { isPremium } = req.body;
      await storage.updateUser(req.params.userId, { isPremium });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  // Chat Routes
  app.get("/api/chat/:userId", async (req, res) => {
    try {
      const messages = await storage.getChatMessages(req.params.userId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const message = await storage.sendMessage(messageData);
      res.json(message);
    } catch (error) {
      res.status(400).json({ error: "VALIDATION_ERROR" });
    }
  });

  app.delete("/api/chat/:userId/:messageId", async (req, res) => {
    try {
      await storage.deleteMessage(req.params.userId, req.params.messageId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  // Notifications
  app.get("/api/notifications/:userId", async (req, res) => {
    try {
      const notifications = await storage.getNotifications(req.params.userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  app.post("/api/notifications", async (req, res) => {
    try {
      const notificationData = insertNotificationSchema.parse(req.body);
      const notification = await storage.createNotification(notificationData);
      res.json(notification);
    } catch (error) {
      res.status(400).json({ error: "VALIDATION_ERROR" });
    }
  });

  // Predictions
  app.get("/api/predictions/:userId", async (req, res) => {
    try {
      const predictions = await storage.getPredictions(req.params.userId);
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ error: "SERVER_ERROR" });
    }
  });

  app.post("/api/predictions", async (req, res) => {
    try {
      const predictionData = insertPredictionSchema.parse(req.body);
      const prediction = await storage.savePrediction(predictionData);
      res.json(prediction);
    } catch (error) {
      res.status(400).json({ error: "VALIDATION_ERROR" });
    }
  });

  return httpServer;
}
