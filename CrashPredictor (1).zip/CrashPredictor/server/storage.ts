import { isFirebaseInitialized, getFirestoreDb } from "./firebase";
import type {
  User,
  InsertUser,
  ChatMessage,
  InsertChatMessage,
  Notification,
  InsertNotification,
  Prediction,
  InsertPrediction,
  AdminDevice,
} from "@shared/schema";

export interface IStorage {
  // User Management
  getUser(id: string): Promise<User | null>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<void>;
  getAllUsers(): Promise<User[]>;
  
  // Admin Device
  getAdminDevice(): Promise<AdminDevice | null>;
  setAdminDevice(deviceId: string): Promise<void>;
  
  // Chat
  getChatMessages(userId: string): Promise<ChatMessage[]>;
  sendMessage(message: InsertChatMessage): Promise<ChatMessage>;
  deleteMessage(userId: string, messageId: string): Promise<void>;
  
  // Notifications
  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  
  // Predictions
  getPredictions(userId: string): Promise<Prediction[]>;
  savePrediction(prediction: InsertPrediction): Promise<Prediction>;
}

export class FirebaseStorage implements IStorage {
  private db;

  constructor() {
    if (!isFirebaseInitialized()) {
      throw new Error('Firebase not initialized - check your FIREBASE_SERVICE_ACCOUNT secret');
    }
    this.db = getFirestoreDb();
  }

  async getUser(id: string): Promise<User | null> {
    const doc = await this.db.collection('users').doc(id).get();
    return doc.exists ? (doc.data() as User) : null;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      joinedAt: Date.now(),
      lastActive: Date.now(),
    };
    
    await this.db.collection('users').doc(user.id).set(user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<void> {
    await this.db.collection('users').doc(id).update({
      ...updates,
      lastActive: Date.now(),
    });
  }

  async getAllUsers(): Promise<User[]> {
    const snapshot = await this.db.collection('users').get();
    return snapshot.docs.map(doc => doc.data() as User);
  }

  async getAdminDevice(): Promise<AdminDevice | null> {
    const doc = await this.db.collection('admin').doc('device').get();
    return doc.exists ? (doc.data() as AdminDevice) : null;
  }

  async setAdminDevice(deviceId: string): Promise<void> {
    const adminDevice: AdminDevice = {
      deviceId,
      registeredAt: Date.now(),
    };
    await this.db.collection('admin').doc('device').set(adminDevice);
  }

  async getChatMessages(userId: string): Promise<ChatMessage[]> {
    const snapshot = await this.db
      .collection('messages')
      .where('userId', '==', userId)
      .orderBy('timestamp', 'asc')
      .get();
    
    return snapshot.docs.map(doc => doc.data() as ChatMessage);
  }

  async sendMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const message: ChatMessage = {
      ...insertMessage,
      id: this.db.collection('messages').doc().id,
      timestamp: Date.now(),
    };
    
    await this.db.collection('messages').doc(message.id).set(message);
    return message;
  }

  async deleteMessage(userId: string, messageId: string): Promise<void> {
    await this.db.collection('messages').doc(messageId).delete();
  }

  async getNotifications(userId: string): Promise<Notification[]> {
    const snapshot = await this.db
      .collection('notifications')
      .where('target', 'in', ['all', userId])
      .orderBy('timestamp', 'desc')
      .get();
    
    return snapshot.docs.map(doc => doc.data() as Notification);
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const notification: Notification = {
      ...insertNotification,
      id: this.db.collection('notifications').doc().id,
      timestamp: Date.now(),
    };
    
    await this.db.collection('notifications').doc(notification.id).set(notification);
    return notification;
  }

  async getPredictions(userId: string): Promise<Prediction[]> {
    const snapshot = await this.db
      .collection('predictions')
      .where('userId', '==', userId)
      .orderBy('timestamp', 'desc')
      .limit(50)
      .get();
    
    return snapshot.docs.map(doc => doc.data() as Prediction);
  }

  async savePrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const prediction: Prediction = {
      ...insertPrediction,
      id: this.db.collection('predictions').doc().id,
      timestamp: Date.now(),
    };
    
    await this.db.collection('predictions').doc(prediction.id).set(prediction);
    return prediction;
  }
}

// In-Memory Fallback Storage
export class MemoryStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private messages: Map<string, ChatMessage[]> = new Map();
  private notifications: Notification[] = [];
  private predictions: Map<string, Prediction[]> = new Map();
  private adminDevice: AdminDevice | null = null;
  private lastNotificationId = 0;

  async getUser(id: string): Promise<User | null> {
    return this.users.get(id) || null;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      joinedAt: Date.now(),
      lastActive: Date.now(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      this.users.set(id, { ...user, ...updates, lastActive: Date.now() });
    }
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getAdminDevice(): Promise<AdminDevice | null> {
    return this.adminDevice;
  }

  async setAdminDevice(deviceId: string): Promise<void> {
    this.adminDevice = { deviceId, registeredAt: Date.now() };
  }

  async getChatMessages(userId: string): Promise<ChatMessage[]> {
    return this.messages.get(userId) || [];
  }

  async sendMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const message: ChatMessage = {
      ...insertMessage,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
    };
    
    const userMessages = this.messages.get(insertMessage.userId) || [];
    userMessages.push(message);
    this.messages.set(insertMessage.userId, userMessages);
    
    return message;
  }

  async deleteMessage(userId: string, messageId: string): Promise<void> {
    const userMessages = this.messages.get(userId) || [];
    this.messages.set(
      userId,
      userMessages.filter(m => m.id !== messageId)
    );
  }

  async getNotifications(userId: string): Promise<Notification[]> {
    return this.notifications.filter(n => n.target === 'all' || n.target === userId);
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const notification: Notification = {
      ...insertNotification,
      id: `notif-${++this.lastNotificationId}-${Date.now()}`,
      timestamp: Date.now(),
      read: false,
    };
    this.notifications.push(notification);
    console.log(`📢 New notification created for ${insertNotification.target}:`, notification);
    return notification;
  }

  async getPredictions(userId: string): Promise<Prediction[]> {
    return this.predictions.get(userId) || [];
  }

  async savePrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const prediction: Prediction = {
      ...insertPrediction,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
    };
    
    const userPredictions = this.predictions.get(insertPrediction.userId) || [];
    userPredictions.unshift(prediction);
    this.predictions.set(insertPrediction.userId, userPredictions.slice(0, 50));
    
    return prediction;
  }
}

// Export storage instance - lazy initialization
let storageInstance: IStorage | null = null;

export function getStorage(): IStorage {
  if (!storageInstance) {
    if (isFirebaseInitialized()) {
      console.log('✅ Using Firebase Storage');
      storageInstance = new FirebaseStorage();
    } else {
      console.log('⚠️  Using In-Memory Storage (data will not persist)');
      storageInstance = new MemoryStorage();
    }
  }
  return storageInstance;
}

// For backward compatibility, export a getter proxy
export const storage = new Proxy({} as IStorage, {
  get: (_, prop) => {
    const instance = getStorage();
    return (instance as any)[prop];
  },
});
